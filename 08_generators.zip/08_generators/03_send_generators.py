def chaiCustomer():
    print("Welcome! What chai would you like?")
    order = yield
    while True:
        print(f"Preparing: {order}")
        order = yield

stall = chaiCustomer()
next(stall) # start generator

stall.send("Masala Chai")
stall.send("Lemon Tea")
