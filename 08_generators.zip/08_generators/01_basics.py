def serveChai():
    yield "Cup1: Masala Chai"
    yield "Cup2: Ginger Chai"
    yield "Cup3: Elaitchi Chai"

stall = serveChai()

# for cup in stall:
#     print(cup)

def getChaiList():
    return ["Cup1", "Cup2", "Cup3"]

# generating function
def getChaigen():
    yield "Cup1"
    yield "Cup2"
    yield "Cup2"

chai = getChaigen()
print(next(chai))
print(next(chai))
print(next(chai))
# print(next(chai)) # error