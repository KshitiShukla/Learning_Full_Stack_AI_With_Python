def localChai():
    yield "Masala Chai"
    yield "Ginger Chai"

def importedChai():
    yield "Matcha"
    yield "Oolong"

def fullMenu():
    yield from localChai()
    yield from importedChai()

for chai in fullMenu():
    print(chai)

# chai = fullMenu()
# print(next(chai))
# print(next(chai))
# print(next(chai))
# print(next(chai))

def chaiStall():
    try:
        while True:
            order = yield "Waiting for chai order"
    except:
        print("Stall Closed, No more chai")

stall = chaiStall()
print(next(stall))
stall.close() # cleanup