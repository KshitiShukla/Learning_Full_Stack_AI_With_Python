def infiniteChai():
    count = 1
    while True:
        yield f"Refill #{count}"
        count +=1

refill = infiniteChai()
user2 = infiniteChai()

for _ in range(5):
    print(next(refill))

for _ in range(6):
    print(next(user2))