# import recipes.flavors

# print(recipes.flavors.gingerChai())

from recipes.flavors import gingerChai, eliatchiChai

print(gingerChai())
print(eliatchiChai())

from recipes.flavors import *

print(gingerChai())
print(eliatchiChai())