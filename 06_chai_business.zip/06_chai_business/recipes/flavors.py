def gingerChai():
    return "Ginger chai"

def eliatchiChai():
    return "Eilatchi Chai"