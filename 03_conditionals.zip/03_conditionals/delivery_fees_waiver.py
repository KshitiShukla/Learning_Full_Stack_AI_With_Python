orderAmount = int(input("Enter your order amount:"))

deliveryFees = 0 if orderAmount > 300 else 30

print(f"Delivery Fees: {deliveryFees}")