seatType = input("Enter seat type(sleeper/ac/general/luxury):").lower()

match seatType:
    case "sleeper":
        print("Sleeper - No AC, beds available")
    case "ac":
        print("AC - Air Conditioned, comfy ride")
    case "general":
        print("General - No reservation available")
    case "luxury":
        print("Luxury - Premium seats, meals included")
    case _:
        print("Invalid seat type")