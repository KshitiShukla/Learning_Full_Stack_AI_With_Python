kettleBoiled = False

if kettleBoiled:
    print("Kettle Done! Time to make tea.")
