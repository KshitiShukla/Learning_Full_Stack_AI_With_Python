from dotenv import load_dotenv
from typing_extensions import TypedDict
from typing import Annotated
from langgraph.graph.message import add_messages
from langgraph.graph import StateGraph, START, END
from langchain.chat_models import init_chat_model
from langgraph.checkpoint.mongodb import MongoDBSaver

load_dotenv()

llm = init_chat_model(
    model="gpt-4.1-mini",
    model_provider="openai"
)

# Important to define the state
class State(TypedDict):
    messages: Annotated[list, add_messages]

def chatbot(state: State):
    response = llm.invoke(state.get("messages"))
    return { "messages": [response] }

graphBuilder = StateGraph(State)

# Node - Basically Function Defining
graphBuilder.add_node("chatbot", chatbot)

# Edges - It's connection between nodes 
graphBuilder.add_edge(START, "chatbot")
graphBuilder.add_edge("chatbot", END)

graph = graphBuilder.compile()
updatedGraph = graph.invoke(State({"messages": "Hi, My name is Kshiti Shukla"}))
print("\n\nupdatedGraph", updatedGraph)