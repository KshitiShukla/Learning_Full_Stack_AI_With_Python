from dotenv import load_dotenv
from typing_extensions import TypedDict
from typing import Optional, Literal
from langgraph.graph import StateGraph, START, END
from openai import OpenAI

load_dotenv()

client = OpenAI()

class State(TypedDict):
    userQuery: str
    llmOutput: Optional[str]
    isGood: Optional[bool]

def chatbot(state: State):
    print("chatbot node", state)
    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            { "role": "user", "content": state.get("userQuery") }
        ]
    )
    state["llmOutput"] = response.choices[0].message.content
    return state

def evaluateResponse(state: State) -> Literal["chatbotGemini", "endnode"]:
    print("evaluateResponse node", state)
    if False:
        return "endnode"
        
    return "chatbotGemini"
    
def chatbotGemini(state: State):
    print("chatbotGemini node", state)
    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            { "role": "user", "content": state.get("userQuery") }
        ]
    )
    state["llmOutput"] = response.choices[0].message.content
    return state

def endnode(state: State):
    print("endnode node", state)
    return state

graphBuilder = StateGraph(State)

graphBuilder.add_node("chatbot", chatbot)
graphBuilder.add_node("chatbotGemini", chatbotGemini)
graphBuilder.add_node("endnode", endnode)

graphBuilder.add_edge(START, "chatbot")
graphBuilder.add_conditional_edges("chatbot", evaluateResponse)

graphBuilder.add_edge("chatbotGemini", "endnode")
graphBuilder.add_edge("endnode", END)

graph = graphBuilder.compile()

updatedGraph = graph.invoke(State({"userQuery": "Hey, what is 2 + 2 ?"}))
print("updatedGraph", updatedGraph)