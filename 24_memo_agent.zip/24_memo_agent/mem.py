from dotenv import load_dotenv
from mem0 import Memory
import os
import json
from openai import OpenAI

load_dotenv()

client = OpenAI()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

config = {
    "version": "v1.1",
    "embedder": {
        "provider": "openai",
        "config": { "api_key": OPENAI_API_KEY, "model": "text-embedding-3-small" }
    },
    "llm": {
        "provider": "openai",
        "config": { "api_key": OPENAI_API_KEY, "model": "gpt-4.1" }
    },
    "graph_store": {
        "provider": "neo4j",
        "config": {
            "url": "neo4j+s://8e8192a2.databases.neo4j.io",
            "username": "neo4j",
            "password": "T4renGKVPeHf5dvJIyt0XKyB9IgX2TCstzrl2ok68n8"
        }
    },
    "vector_store": {
        "provider": "qdrant",
        "config": {
            "host": "localhost",
            "port": 6333
        }
    }
}

memClient = Memory.from_config(config)

while True:
    userQuery = input("> ")

    searchMemory = memClient.search(query=userQuery, user_id="kshitishukla")

    memories = [
        f"ID: {mem.get("id")}\nMemory: {mem.get("memory")}" for mem in searchMemory.get("results")
    ]

    print("Found Memories", memories)

    SYSTEM_PROMPT = f""" 
    Here is the context about the user:
    {json.dumps(memories)} 
    """

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            { "role": "system", "content": SYSTEM_PROMPT },
            { "role": "user", "content": userQuery }
        ]
    )

    aiResponse = response.choices[0].message.content

    print("AI:", aiResponse)

    memClient.add(
        user_id="kshitishukla",
        messages=[
            { "role": "user", "content": userQuery },
            { "role": "assistant", "content": aiResponse }
        ]
    )

    print("Memory has been saved...")