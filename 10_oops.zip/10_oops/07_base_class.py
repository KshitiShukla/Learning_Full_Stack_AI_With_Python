class Chai:
    def __init__(self, type_, strength):
        self.type = type_
        self.strength = strength

# class GingerChai(Chai):
#     def __init__(self, type_, strength, spiceLevel):
#         self.type = type_
#         self.strength = strength
#         self.spiceLevel = spiceLevel

# class GingerChai(Chai):
#     def __init__(self, type_, strength, spiceLevel):
#         Chai.__init__(self, type_, strength)
#         self.spiceLevel = spiceLevel

class GingerChai(Chai):
    def __init__(self, type_, strength, spiceLevel):
        super().__init__(type_, strength)
        self.spiceLevel = spiceLevel
