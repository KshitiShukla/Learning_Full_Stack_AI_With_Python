class BaseChai:
    def __init__(self, type_):
        self.type = type_

    def prepare(self):
        print(f"Preparing {self.type} chai....")

class MasalaChai(BaseChai):
    def addSpices(self):
        print("Adding cardamom, ginger and cloves.")


class ChaiShop:
    chaiCls = BaseChai

    def __init__(self):
        self.chai = self.chaiCls("Regular")

    def serve(self):
        print(f"Serving {self.chai.type} chai in shop")
        self.chai.prepare()

class FancyChaiShop(ChaiShop):
    chaiCls = MasalaChai

shop = ChaiShop()
fancy = FancyChaiShop()
shop.serve()
fancy.serve()
fancy.chai.addSpices()