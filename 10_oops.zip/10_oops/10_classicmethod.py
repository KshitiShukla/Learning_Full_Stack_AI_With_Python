class ChaiOrder:
    def __init__(self, teaType, sweetness, size):
        self.teaType = teaType
        self.sweetness = sweetness
        self.size = size

    @classmethod
    def fromDict(cls, orderData):
        return cls(
            orderData["teaType"],
            orderData["sweetness"],
            orderData["size"],
        )
    
    @classmethod
    def fromStr(cls, orderString):
        teaType, sweetness, size = orderString.split("-")
        return cls(teaType, sweetness, size)
    
class ChaiUtils:
    @staticmethod
    def isValidSize(size):
        return size in ["Small", "Medium", "Large"]

print(ChaiUtils.isValidSize("Meidum")) 

order1 = ChaiOrder.fromDict({"teaType" : "Masala", "sweetness" : "medium", "size": "small"})
order2 = ChaiOrder.fromStr("Ginger-low-medium")

print(order1.__dict__)