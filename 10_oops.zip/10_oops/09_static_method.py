class ChaiUtils:
    @staticmethod
    def cleanedIngredients(text):
        return [item.strip() for item in text.split(",")]
    
raw = " water,  ginger,  milk , honey "

# obj = ChaiUtils()
# obj.cleanedIngredients(raw)

cleaned = ChaiUtils.cleanedIngredients(raw)
print(cleaned)