class Chai:
    pass

class ChaiTime:
    pass

print(type(Chai))

gingerChai = Chai()

print(type(gingerChai))
print(type(gingerChai) is Chai)
print(type(gingerChai) is ChaiTime)