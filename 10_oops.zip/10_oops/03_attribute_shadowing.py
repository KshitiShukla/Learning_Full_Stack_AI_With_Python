class Chai:
    temperature = "Hot"
    strength = "Strong"

cutting = Chai()

print(cutting.temperature)

cutting.temperature = "Mild"
cutting.cup = "small"
print("After changing:",cutting.temperature)
print("Cutting cup size:",cutting.cup)
print("Direct from class look up:",Chai.temperature)

del cutting.temperature
del cutting.cup
print(cutting.temperature)
print(cutting.cup)