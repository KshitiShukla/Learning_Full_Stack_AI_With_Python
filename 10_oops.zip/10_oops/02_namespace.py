class Chai:
    origin = "India"
    # isHot = True

print(Chai.origin)

Chai.isHot = True
print(Chai.isHot)

# creating objects from class chai

masala = Chai()
print(f"Masala {masala.origin}")
print(f"Masala {masala.isHot}")
masala.isHot = False

print("Class: ", Chai.isHot)
print(f"Masala {masala.isHot}")