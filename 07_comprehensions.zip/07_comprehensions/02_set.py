favouriteChai = [
    "Masala Chai", "Green Tea", "Masala Chai",
    "Lemon Tea", "Green Tea", "Ginger Chai"
]

uniqueChai = {chai for chai in favouriteChai if len(chai) < 8}

print(uniqueChai)

recipes = {
    "Masala Chai" : ["Ginger", "clove", "cardamom"],
    "Elaichi Chai" : ["cardamom", "milk"],
    "Spicy Chai" : ["Ginger", "blackpepper", "clove"]
}

uniqueSpices = {spice for ingredients in recipes.values() for spice in ingredients}

print(uniqueSpices)