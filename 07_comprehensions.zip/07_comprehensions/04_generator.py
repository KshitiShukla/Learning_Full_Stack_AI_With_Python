dailySales = [5, 10, 12, 7, 3, 8, 9, 15]

totalCups = sum(sale for sale in dailySales if sale > 5)
# totalCups = [sale for sale in dailySales if sale > 9]

print(totalCups)