menu = [
    "Masala Chai",
    "Iced Lemon Tea",
    "Green Tea",
    "Iced Peach Tea",
    "Ginger Chai"
]

# icedTea = [myTea for myTea in menu if len(myTea) > 15]
icedTea = [tea for tea in menu if "Iced" in tea]

print(icedTea)