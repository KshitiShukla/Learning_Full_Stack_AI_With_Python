orders = ["Pranati", "Mantra", "Jayani", "Ragni"]

for name in orders: 
    print(f"Order Served for: {name}")