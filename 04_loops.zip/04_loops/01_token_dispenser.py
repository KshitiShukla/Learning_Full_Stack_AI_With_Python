for token in range(1, 11):
    print(f"Serving chai to token: #{token}")