temperature = 40

while temperature < 100:
    print(f"Current temperature: {temperature}")
    temperature += 15
print("Tea is ready to boil")