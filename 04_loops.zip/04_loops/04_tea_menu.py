menu = ["Green", "Mint", "Lemon", "Ice"]

# for item in menu:
#     print(f"Menu item is : {item}")

# enumerate function
for idx, item in enumerate(menu, start=1):
    print(f"{idx} : {item} tea")