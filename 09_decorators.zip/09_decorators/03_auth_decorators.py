from functools import wraps

def requiredAdmin(func):
    @wraps(func)
    def wrapper(userRole):
        if userRole != "admin":
            print("Access Denied, Admin Only!")
            return None
        else:
            return func(userRole)
    return wrapper

@requiredAdmin
def accessTeaInventory(role):
    print("Access granted to tea inventory")

accessTeaInventory("user")
accessTeaInventory("admin")