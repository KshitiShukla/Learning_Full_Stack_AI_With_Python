def serveChai(flavor):
    try:
        print(f"Preparing {flavor} chai....")
        if flavor == "unknown":
            raise ValueError("We don't serve this flavor of chai")
    except ValueError as e:
        print("Error:",e)
    else:
        print(f"{flavor} chai is served")
    finally:
        print(f"Next customer please")

serveChai("masala")
serveChai("unknown")