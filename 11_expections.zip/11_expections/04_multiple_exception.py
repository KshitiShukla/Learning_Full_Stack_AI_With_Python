def processOrder(item, quantity):
    try:
        price = {"masala": 20}[item]
        cost = price * quantity
        print(f"Total cost is {cost}")
    except KeyError:
        print("Sorry that chai is not in our menu")
    except TypeError:
        print("Quantity must be in number")

processOrder("ginger", 2)
processOrder("masala", "two")