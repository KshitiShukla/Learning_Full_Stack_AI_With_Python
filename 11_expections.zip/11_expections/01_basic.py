orders = ["masala", "lemon"]

print(orders[2])