def brewChai(flavor):
    if flavor not in ["masala", "ginger", "lemon"]:
        raise ValueError("Unsupported Chai........")
    print(f"flavor {brewChai} chai.......")

brewChai("mint")