chaiMenu = {"masala" : 30, "ginger" : 40}

try:
    chaiMenu["eliachi"]
except KeyError:
    print("KeyError happend in Dictionary while trying to access")


print("Hello Kshiti")