class OutOfIngredientsError(Exception):
    pass

def makeChai(milk, sugar):
    if milk == 0 or sugar == 0:
        raise OutOfIngredientsError("Qunatity of milk and sugar is not supporting....")
    print(f"your chai is ready......")

makeChai(0, 1)