def pureChai(cups):
    return cups * 10

totalChai = 0

def impureChai(cups):
    global totalChai
    totalChai += cups

def pourChai(n):
    print(n)
    if n == 0:
        return "All cups are poured"
    return pourChai(n-1)

print(pourChai(3))


# chaiTypes = ["light", "kadak", "ginger", "kadak"]

# storeChai = list(filter(lambda chai: chai=="kadak", chaiTypes))

# print(storeChai)


chaiTypes = ["lemon", "mint", "mint", "ginger", "ginger", "blackpepper", "eliachi"]

storeChai = list(filter(lambda chai: chai in ("ginger", "mint"), chaiTypes))

print(storeChai)