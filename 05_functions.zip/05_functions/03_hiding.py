def getInput():
    print("Getting User Input")

def validateInput():
    print("Validing User Input Info")

def saveToDB():
    print("Save it to the Database")

def registerUser():
    getInput()
    validateInput()
    saveToDB()
    print("User registration complete")

registerUser()