def calculateBill(cups, pricePerCup):
    return cups * pricePerCup

myBill = calculateBill(3, 15)
print(myBill)

print("Order for table 2:",calculateBill(2,50))