chaiType = "ginger"

def updateOrder():
    chaiType = "Elaitchi"
    def kitchen():
        nonlocal chaiType
        chaiType = "Kesar"
    kitchen()
    print("After kitchen update", chaiType)

updateOrder() 