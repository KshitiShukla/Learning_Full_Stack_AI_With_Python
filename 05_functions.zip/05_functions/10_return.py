# def makeChai():
#     # return "Here is your masala chai"
#     print("Here is your masala chai")

# returnValue = makeChai()

# print(returnValue)

def idealChaiWala():
    pass

print(idealChaiWala())

def soldCups():
    return 120

total = soldCups()
print(total)

def chaiStatus(cupsLeft):
    if cupsLeft == 0:
        return "Sorry, Chai is over"
    return "Chai is ready"

print(chaiStatus(0))
print(chaiStatus(5))

def chaiReport():
    return 100, 20, 10 # sold, remaining

sold, remaining, notPaid = chaiReport()
print("Sold:", sold)
print("Remaining:", remaining)