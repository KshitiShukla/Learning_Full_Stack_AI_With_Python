# chai = "Ginger Tea"

# def preparingChai(order):
#     print("Preparing", order)

# preparingChai(chai)
# print(chai)

chai = [1, 2, 3]

def editChai(cup):
    cup[1] = 42

editChai(chai)
print(chai)

def makeChai(tea, milk, sugar):
    print(tea, milk, sugar)

makeChai("Darjeeling", "yes", "low") # positional
makeChai(tea="Lemon", sugar="medium", milk="no") #keywords


def specialChai(*ingredients, **extras):
    print("Ingredients:", ingredients)
    print("Extras:", extras)

specialChai("Lemon", "Mint", sweetness="Honey", foam="yes")

def chaiOrder(order = []):
    order.append("Masala")
    print(order)

def chaiOrder(order=None):
    order.append("Masala")
    print(order)