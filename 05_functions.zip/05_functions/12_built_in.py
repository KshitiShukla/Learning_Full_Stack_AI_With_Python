def chaiFlavor(flavor="masala"):
    chai = "ginger"
    """Retrun the flavor of chai"""
    return chaiFlavor

print(chaiFlavor.__doc__)
print(chaiFlavor.__name__)

def generateBills(chai=0, samosa=0):
    """
    Calculate the bill of chai and samosa

    :params chai: Number of chai rupees (10 ruppes)
    :params samosa: Number of samosa rupees (15 rupees)
    :return message Thank you for visiting
    """
    total = chai*10 + samosa*10
    return total, "Thank you for visiting chai sutta bar"

print(generateBills.__doc__)
print(generateBills.__name__)
print(generateBills(11, 2))