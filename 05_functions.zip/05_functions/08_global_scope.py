chaiType = "Plain"

def frontDesk():
    def kitchen():
        global chaiType
        chaiType = "Irnai"
    kitchen()

frontDesk()
print("Final Global Chai:", chaiType)