def fetchSales():
    print("Fetching Sales Data")

def filterValidData():
    print("Filtering Valid Data")

def summarizeData():
    print("Summarize Data")

def generateReport():
    fetchSales()
    filterValidData()
    summarizeData()
    print("Report is ready")

generateReport()