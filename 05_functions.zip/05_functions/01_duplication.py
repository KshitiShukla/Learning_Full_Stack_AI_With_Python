def printOrder(name, chaiType):
    print(f"{name} ordered {chaiType} chai!")

printOrder("Mantra", "Masala")
printOrder("Pranati", "Ginger")
printOrder("Jayani", "Tulsi")