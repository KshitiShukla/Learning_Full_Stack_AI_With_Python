def serveChai():
    chaiType = "Masala" # Local
    print(f"Inner: {chaiType}")

chaiType = "Lemon"
serveChai()
print(f"Outer: {chaiType}")

def chaiCounter():
    chaiOrder = "Lemon" # Enclosing
    def printOrder():
        chaiOrder = "Ginger"
        print("Inner:", chaiOrder)
    printOrder()
    print("Outside:", chaiOrder)

chaiOrder = "Tulsi"
chaiCounter()
print("Global:", chaiOrder)
