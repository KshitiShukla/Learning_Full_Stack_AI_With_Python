isBoiling = True
striCount = 5
totalActions = striCount + isBoiling  # upcasting
print(f"Total actions: {totalActions}")

milkPresent = 0 # no milk
print(f"Is there mik? {bool(milkPresent)}")

waterHot = True
teaAdded = True
canServe = waterHot and teaAdded
print(f"Can serve tea?: {canServe}")