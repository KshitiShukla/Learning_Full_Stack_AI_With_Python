# Integer
blackTeaGrams = 12
gingerTeaGrams = 4

totalTeaGrams = blackTeaGrams + gingerTeaGrams
print(f"Total tea grams: {totalTeaGrams}")

remainingTeaGrams = blackTeaGrams - gingerTeaGrams
print(f"Remaining tea grams: {remainingTeaGrams}")

milkServing = 7
servings= 4
milkPerServing = milkServing / servings
print(f"Milk per serving: {milkPerServing}")

totalPerBag = 7
pots = 4
totalPerPot = totalPerBag // pots
print(f"Total per pot: {totalPerPot}")

totalcardamom = 10
pods = 3
totalPotsCardamom = totalcardamom % pods
print(f"Total pots cardamom: {totalPotsCardamom}")

baseFlavorStrength = 2
scaleFactor = 3
powerfulFlavor = baseFlavorStrength ** scaleFactor
print(f"Powerful flavor strength: {powerfulFlavor}")
# 2 * 2 * 2 

totalTeaLeavesHarvested = 1_000_000_000
print(f"Total tea leaves harvested: {totalTeaLeavesHarvested}")