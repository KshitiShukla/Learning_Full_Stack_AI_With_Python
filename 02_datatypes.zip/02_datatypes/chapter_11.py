import arrow

brewingTime = arrow.utcnow()
brewingTime.to("Europe/Rome")

from collections import namedtuple