masalaSpices = ("cardamom", "cloves", "cinnamon")

(spices1, spices2, spices3) = masalaSpices

print(f"Masala Spices: {spices1}, {spices2}, {spices3}")

gingerRatio, cardamomRatio = 2, 1
print(f"Ration is G: {gingerRatio} and Ratio is C: {cardamomRatio}")
gingerRatio, cardamomRatio = cardamomRatio, gingerRatio
print(f"Ration is G: {gingerRatio} and Ratio is C: {cardamomRatio}")

# membership

print(f"Is ginger in masalaSpices? {'ginger' in masalaSpices}")