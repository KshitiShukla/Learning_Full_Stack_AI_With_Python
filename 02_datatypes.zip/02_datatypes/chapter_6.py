chaiType = "Ginger Chai"
customerName = "Priya"

print(f"Order for {customerName} : {chaiType} please!")

chaiDescription = "Aromatic and Bold"
print(f"First Word: {chaiDescription[0:8]}")
print(f"Last Word: {chaiDescription[12:]}")
print(f"Middle Word: {chaiDescription[9:12]}")
print(f"Last Word: {chaiDescription[::-1]}")

labelText = "Chai Spécial"
encodingText = labelText.encode("utf-8")
print(f"Normal Text: {labelText}")
print(f"Encoded Text: {encodingText}")
decodingText = encodingText.decode("utf-8")
print(f"Decoded Text: {decodingText}")