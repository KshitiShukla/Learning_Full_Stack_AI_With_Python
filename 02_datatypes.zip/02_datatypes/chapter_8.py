ingredients = ["milk", "water", "black tea"]
ingredients.append("sugar")
print(f"Ingredients are: {ingredients}")
ingredients.remove("black tea")
print(f"Ingredients are: {ingredients}")

spicesOptions = ["ginger", "cardamom"]
chaiIngredients = ["water", "milk"]

chaiIngredients.extend(spicesOptions)
print(f"Chai: {chaiIngredients}")
chaiIngredients.insert(2, "black tea")
print(f"Chai: {chaiIngredients}")

lastAdded = chaiIngredients.pop()
print(f"{lastAdded}")
print(f"Chai: {chaiIngredients}")
chaiIngredients.reverse()
print(f"Chai: {chaiIngredients}")
chaiIngredients.sort()
print(f"Chai: {chaiIngredients}")

sugarLevel = [1, 2, 3, 4, 5]
print(f"Max sugar level: {max(sugarLevel)}")
print(f"Min sugar level: {min(sugarLevel)}")

baseLiquid = ["water", "milk"]
extraFlavor = ["ginger"]

fullLiquidMix = baseLiquid + extraFlavor
print(f"Liquid Mix: {fullLiquidMix}")

strongBrew = ["black tea", "water"] * 3
print(f"Strong Brew: {strongBrew}")

rawSpicesData = bytearray(b"CINNAMON")
rawSpicesData = rawSpicesData.replace(b"CINNA", b"CARD")
print(f"Bytes: {rawSpicesData}")