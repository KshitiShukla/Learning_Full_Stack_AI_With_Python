chaiOrder = dict(type="Masala Chai", size="Large", sugar=2)
print(f"Chai Order: {chaiOrder}")

chaiRecipe = {}
chaiRecipe["base"] = "Black Tea"
chaiRecipe["liquid"] = "milk"

print(f"Recipe base: {chaiRecipe['base']}")
print(f"Recipe: {chaiRecipe}")
del chaiRecipe["liquid"] 
print(f"Recipe: {chaiRecipe}")

print(f"Is sugar in the order? {'sugar' in chaiOrder}")

chaiOrder = {"type": "Ginger Chai", "size": "Medium", "sugar": 1}

# print(f"Order details (keys): {chaiOrder.keys()}")
# print(f"Order details (values): {chaiOrder.values()}")
# print(f"Order details (items): {chaiOrder.items()}")

lastItem = chaiOrder.popitem()
print(f"Removed last item: {lastItem}")

extraSpices = {"cardamom": "crushed", "cinnamon": "sliced"}
chaiRecipe.update(extraSpices)

print(f"Update Chai Recipe: {chaiRecipe}")

customerNote = chaiOrder.get("note", "No note")
print(f"Customer Note: {customerNote}")