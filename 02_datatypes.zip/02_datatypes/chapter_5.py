import sys
from fractions import Fraction
from decimal import Decimal as D

idealTemp = 95.5
currentTemp = 95.499999999999

print(f"Ideal Temp: { idealTemp }")
print(f"Current Temp: { currentTemp }")
print(f"Difference Temp: { idealTemp - currentTemp }")
print(sys.float_info)