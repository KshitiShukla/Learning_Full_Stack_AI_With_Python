sugarAmount = 2
print(f"Initial sugar amount: {sugarAmount}")

sugarAmount = 12
print(f"Second sugar amount: {sugarAmount}")

print(f"ID of id(2): {id(2)}")
print(f"ID of id(12): {id(12)}")