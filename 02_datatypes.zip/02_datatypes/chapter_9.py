essentialSpices = {"cardamom", "ginger", "cinnamon"}
optionalSpices = {"cloves", "ginger", "black pepper"}

allSpices = essentialSpices | optionalSpices
print(f"All spices: {allSpices}")

commonSpices = essentialSpices & optionalSpices
print(f"Common spices: {commonSpices}")

onlyInEssential = essentialSpices - optionalSpices
print(f"Only in essential spices: {onlyInEssential}")

print(f"Is cloves in optional spices? {'cloves' in optionalSpices}")