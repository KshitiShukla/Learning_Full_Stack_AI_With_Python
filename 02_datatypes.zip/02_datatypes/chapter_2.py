spiceMix = set()
print(f"Initial spice mix id: {id(spiceMix)}")
print(f"Initial spice mix id: {spiceMix}")

spiceMix.add("Ginger")
spiceMix.add("cardamom")

print(f"Initial spice mix id: {spiceMix}")
print(f"After spice mix id: {id(spiceMix)}")